import React, { useEffect, useState } from 'react';
import ChatBubble from './MessageBubble.jsx';
import ChatInput from './ChatInput.jsx';
import { getMessages, saveMessage } from '../services/chatApi.js'; // ✅ 경로 수정
import { getLLMResponse } from '../services/llmApi.js';             // ✅ 경로 수정

export default function ChatWindow({ currentSession, onSessionUpdated }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    if (currentSession?.id) {
      getMessages(currentSession.id).then(setMessages);
    }
  }, [currentSession]);

  const handleSend = async () => {
    if (!input.trim() || !currentSession?.id) return;

    const sessionId = currentSession.id;

    const userMsg = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    await saveMessage({ sessionId, ...userMsg });

    const aiContent = await getLLMResponse(input);
    const aiMsg = { role: 'ai', content: aiContent };
    setMessages(prev => [...prev, aiMsg]);
    await saveMessage({ sessionId, ...aiMsg });

    setInput('');
    onSessionUpdated();
  };

  return (
    <div className="flex flex-col h-full px-4 py-2">
      <div className="flex-1 overflow-y-auto">
        {messages.length === 0 ? (
          <div className="text-center text-gray-400 mt-10 text-sm">
            퇴근하고 싶으시죠? 일하세요.
          </div>
        ) : (
          messages.map((msg, idx) => (
            <ChatBubble
              key={idx}
              sender={msg.role}
              text={msg.content}
            />
          ))
        )}
      </div>
      <ChatInput
        value={input}
        onChange={setInput}
        onSend={handleSend}
      />
    </div>
  );
}
