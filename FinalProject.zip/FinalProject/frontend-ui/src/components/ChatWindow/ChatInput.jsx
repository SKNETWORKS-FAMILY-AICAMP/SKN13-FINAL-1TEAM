// src/components/ChatWindow/ChatInput.jsx
import React from 'react';

export default function ChatInput({ input, setInput, onSend, file, setFile }) {
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  return (
    <div className="flex items-end gap-2 px-4 py-3 border-t">
      {/* 파일 업로드 */}
      <label className="text-xl w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 cursor-pointer">
        ＋
        <input
          type="file"
          className="hidden"
          onChange={(e) => setFile(e.target.files[0])}
        />
      </label>

      {/* 메시지 입력창 */}
      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="메시지를 입력하세요"
        rows={1}
        className="flex-1 p-2 rounded-full border border-gray-300 text-sm resize-none focus:outline-none"
      />

      {/* 전송 버튼 */}
      <button
        className="text-xl text-blue-500 font-bold"
        onClick={onSend}
      >
        ➤
      </button>
    </div>
  );
}
