export const API_BASE = 'http://localhost:8000'; // 🔧 배포 시 여기를 변경
export const LLM_API_BASE = 'http://localhost:8000'; // 🔧 LLM 전용 API 주소