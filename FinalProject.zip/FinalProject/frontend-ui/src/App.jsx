import React, { useState, useEffect } from 'react';
import ChatWindow from './components/ChatWindow/ChatWindow.jsx';
import Sidebar from './components/Sidebar/Sidebar.jsx';
import HeaderBar from './components/shared/HeaderBar.jsx';
import { getChatSessions } from './components/services/chatApi';

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sessionList, setSessionList] = useState([]);
  const [currentSession, setCurrentSession] = useState(null);

  const loadSessions = async () => {
    const sessions = await getChatSessions();
    setSessionList(sessions);
  };

  const handleNewChat = () => {
    const newSession = {
      id: `session-${Date.now()}`,
      title: '새로운 대화',
    };
    setCurrentSession(newSession);
  };

  const handleSelectChat = (sessionId) => {
    setCurrentSession({ id: sessionId });
    setSidebarOpen(false);
  };

  useEffect(() => {
    loadSessions();
  }, []);

  return (
    <div className="h-screen flex flex-col bg-white">
      <HeaderBar
        onMenuClick={() => setSidebarOpen(true)}
        showMenuButton={!sidebarOpen}
      />

      <div className="flex flex-1 overflow-hidden">
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-30 z-40"
            onClick={() => setSidebarOpen(false)}
          >
            <div
              className="absolute left-0 top-0 h-full w-64 bg-white shadow-lg z-50"
              onClick={(e) => e.stopPropagation()}
            >
              <Sidebar
                onClose={() => setSidebarOpen(false)}
                sessions={sessionList}
                onNewChat={handleNewChat}
                onSelectChat={handleSelectChat}
              />
            </div>
          </div>
        )}

        <div className="flex-1 flex flex-col">
          <ChatWindow
            currentSession={currentSession}
            onSessionUpdated={loadSessions}
          />
        </div>
      </div>
    </div>
  );
}
